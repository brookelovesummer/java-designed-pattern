package myjava;

public class Counter {
	
	private static Counter instance = null;
	int i = 0;
	private Counter(){
		
	}
	public int getversioncount(){
		return ++i;
	}
	public static Counter getinstance(){
		synchronized (Counter.class) {
			if(instance == null)
				instance = new Counter();
		}
		return instance;
	}

}
