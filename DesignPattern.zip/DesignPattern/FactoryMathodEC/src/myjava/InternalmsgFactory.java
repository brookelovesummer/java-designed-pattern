package myjava;

public class InternalmsgFactory implements SenderFactory {

	@Override
	public MsgNotification create() {
		return new InternalmsgNotification();
	}

}
