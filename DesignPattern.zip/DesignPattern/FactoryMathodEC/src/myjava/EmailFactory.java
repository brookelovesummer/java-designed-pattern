package myjava;

public class EmailFactory implements SenderFactory{

	@Override
	public MsgNotification create() {
		return new EmailNotification();
	}

}
