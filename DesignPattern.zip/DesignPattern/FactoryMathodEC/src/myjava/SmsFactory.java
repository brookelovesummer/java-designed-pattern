package myjava;

public class SmsFactory implements SenderFactory{

	@Override
	public MsgNotification create() {
		return new SmsNotification();
	}

}
