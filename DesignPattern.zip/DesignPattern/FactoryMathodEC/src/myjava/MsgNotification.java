package myjava;

public interface MsgNotification {
	void send();
}
