package web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Observers.NameObserver;
import Observers.PriceObserver;
import model.Product;

/**
 * Servlet implementation class Update
 */
@WebServlet("/Update")
public class Update extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Update() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");//һ������²���Ҫ�ӣ�������������룬��仰���Ǻܹ��õ�
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		String pname = request.getParameter("name");
		String pprice = request.getParameter("price");
		System.out.println(pname);
		
		Product product = new Product();
		PriceObserver priceroberserver = new PriceObserver();
		NameObserver nameobserver = new NameObserver();
		
		product.addObserver(nameobserver);
		product.addObserver(priceroberserver);
		
		if(pname != null && pname != ""){
			product.setName(pname);
		}
		if(pprice != null && pprice != ""){
			product.setPrice(Double.parseDouble(pprice));
		}
		if(pname != null && pname != "" && pprice != null && pprice != ""){
			out.println("��Ʒ��Ϣ�޸����£�");
			out.println("��Ʒ����"+product.getName());
			out.println("��Ʒ�۸�"+product.getPrice());
		}else{
			out.println("��Ʒ��Ϣδ�޸ģ�");
		}
	}
	
}
