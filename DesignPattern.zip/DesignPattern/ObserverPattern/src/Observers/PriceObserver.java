package Observers;

import java.util.Observable;
import java.util.Observer;

public class PriceObserver implements Observer{

	@Override
	public void update(Observable o, Object arg) {
		if(arg instanceof Double){
			double price = (double)arg;
			System.out.println("PriceObserver:Price has changed to "+price);
		}
		
	}

}
