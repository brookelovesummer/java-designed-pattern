package Observers;

import java.util.Observable;
import java.util.Observer;

public class NameObserver implements Observer {

	@Override
	public void update(Observable o, Object arg) {
		if(arg instanceof String){
			String name = (String)arg;
			System.out.println("NameObserver:name has changed to "+name);
		}
		
	}

}
