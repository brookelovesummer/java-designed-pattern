package ConcrecteDecorator;

import AbstractComponent.phone;
import AbstractDecorator.attachment;

public class memorycard extends attachment {

	public double memoryprice;
	
	public memorycard(double memoryprice,phone x) {
		super(x);
		this.memoryprice = memoryprice;
	}
	public String getDescription(){
		return super.getDescription()+"+�洢��";
	}
	public double cost(){
		return super.cost()+this.memoryprice;
	}
	public double getMemoryprice() {
		return this.memoryprice;
	}
	

}
