package ConcrecteDecorator;

import AbstractComponent.phone;
import AbstractDecorator.attachment;

public class phoneshell extends attachment {

	public double shellprice;
	
	public phoneshell(double shellprice,phone x) {
		super(x);
		this.shellprice = shellprice;
	}
	public String getDescription(){
		return super.getDescription()+"+�ֻ���";
	}
	public double cost(){
		return super.cost()+this.shellprice;
	}
	public double getShellprice() {
		return this.shellprice;
	}
	

}
