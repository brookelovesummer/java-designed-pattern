package ConcrecteDecorator;

import AbstractComponent.phone;
import AbstractDecorator.attachment;

public class bluetooth extends attachment {

	public double bluetoothprice;
	public bluetooth(double blueprice,phone x) {
		super(x);
		this.bluetoothprice = blueprice;
	}
	
	public String getDescription(){
		return super.getDescription()+"+�������";
	}
	public double cost(){
		return super.cost()+this.bluetoothprice;
	}

	public double getBluetoothprice() {
		return this.bluetoothprice;
	}
	
}
