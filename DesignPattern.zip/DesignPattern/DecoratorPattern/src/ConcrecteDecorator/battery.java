package ConcrecteDecorator;

import AbstractComponent.phone;
import AbstractDecorator.attachment;

public class battery extends attachment{
	
	public double batteryprice;

	public battery(double batteryprice,phone x) {
		super(x);
		this.batteryprice = batteryprice;
	}

	@Override
	public String getDescription() {
		return super.getDescription()+"+���";
	}

	public double getBatteryprice() {
		return this.batteryprice;
	}

	public double cost(){
		return super.cost()+ this.batteryprice;
	}
	
	

	
}
