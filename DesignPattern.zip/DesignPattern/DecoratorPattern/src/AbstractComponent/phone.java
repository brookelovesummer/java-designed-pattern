package AbstractComponent;

public abstract class phone {

	public String description = "δ֪";



	public String getDescription() {
		return description;
	}

	public abstract double cost();
	
}
