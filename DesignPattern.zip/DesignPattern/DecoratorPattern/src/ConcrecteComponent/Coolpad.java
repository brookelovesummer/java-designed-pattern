package ConcrecteComponent;

import AbstractComponent.phone;

public class Coolpad extends phone{

	public double orignalprice;
	public Coolpad(double orignalprice){
		this.orignalprice = orignalprice;
		description = "���� 8750 4G�ֻ����������OFDMA";
	}
	
	@Override
	public double cost() {
		return orignalprice;
	}

	@Override
	public String getDescription() {
		return description;
	}

}
