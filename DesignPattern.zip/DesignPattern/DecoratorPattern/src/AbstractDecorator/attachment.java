package AbstractDecorator;

import AbstractComponent.phone;

public abstract class attachment extends phone {

	phone x;

	public attachment(phone x) {
		this.x = x;
	}

	@Override
	public double cost() {
		return x.cost();
	}
	
	public String getDescription(){
		return x.getDescription();
	}
	
}
