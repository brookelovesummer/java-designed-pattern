package Web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import AbstractComponent.phone;
import ConcrecteComponent.Coolpad;
import ConcrecteDecorator.battery;
import ConcrecteDecorator.bluetooth;
import ConcrecteDecorator.memorycard;
import ConcrecteDecorator.phoneshell;

/**
 * Servlet implementation class Checkout
 */
@WebServlet("/Checkout")
public class Checkout extends HttpServlet {
	private static final long serialVersionUID = 1L;
        
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Checkout() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		try{
			String ck1 = request.getParameter("ck1");
			String ck2 = request.getParameter("ck2");
			String ck3 = request.getParameter("ck3");
			String ck4 = request.getParameter("ck4");
			String phoneprice = request.getParameter("phoneprice");
			String memoryprice = request.getParameter("memoryprice");
			String bluetoothprice = request.getParameter("bluetoothprice");
			String batteryprice = request.getParameter("batteryprice");
			String shellprice = request.getParameter("shellprice");
						
			phone x = new Coolpad(Double.parseDouble(phoneprice));
			if(ck1 != null){
				x = new memorycard(Double.parseDouble(memoryprice), x);//��x���ϴ洢��װ��
			}
			if(ck2 != null){
				x = new bluetooth(Double.parseDouble(bluetoothprice), x);//��x�����������װ��
			}
			if(ck3 != null){
				x = new battery(Double.parseDouble(batteryprice), x);//��x���ϵ��װ��
			}
			if(ck4 != null){
				x = new phoneshell(Double.parseDouble(shellprice), x);//��x�����ֻ���װ��
			}
			out.println(x.getDescription());
			out.println(x.cost()+"  Ԫ");
			
		}finally{
			out.close();
		}
		
	}

}
