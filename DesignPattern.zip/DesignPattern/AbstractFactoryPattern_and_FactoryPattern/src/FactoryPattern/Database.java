package FactoryPattern;

public interface Database {
	public void access();
}
