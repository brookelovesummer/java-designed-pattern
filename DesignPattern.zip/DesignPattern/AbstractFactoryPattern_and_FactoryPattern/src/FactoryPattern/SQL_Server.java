package FactoryPattern;

public class SQL_Server implements Database {
	public static final String name = "SQL Server";
	@Override
	public void access() {
		System.out.println("select Top 2 * from persons");
	}
	public SQL_Server() {
		System.out.println("The database's name is "+name);
	}

}
