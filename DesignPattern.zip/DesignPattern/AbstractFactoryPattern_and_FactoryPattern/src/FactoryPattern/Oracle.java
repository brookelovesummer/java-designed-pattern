package FactoryPattern;

public class Oracle implements Database {
	public static final String name = "Oracle";
	@Override
	public void access() {
		System.out.println("select * from persons where rownum <=3");
	}
	public Oracle() {
		System.out.println("The database's name is "+name);
	}
}
