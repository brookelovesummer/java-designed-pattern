package FactoryPattern;

public class MySQL_Factory implements AccessFactory{

	@Override
	public Database create() {
		return new MySQL();
	}
}
