package FactoryPattern;

public class Oracle_Factory implements AccessFactory {

	@Override
	public Database create() {
		return new Oracle();
	}

}
