package FactoryPattern;

public class MySQL implements Database {

	public static final String name = "MySQL";
	@Override
	public void access() {
		System.out.println("select * from persons where rownum <=3");
	}
	public MySQL() {
		System.out.println("The database's name is "+name);
	}
}
