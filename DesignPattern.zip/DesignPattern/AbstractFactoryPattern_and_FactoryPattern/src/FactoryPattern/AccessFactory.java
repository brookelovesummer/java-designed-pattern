package FactoryPattern;

public interface AccessFactory {
	public Database create();
}
