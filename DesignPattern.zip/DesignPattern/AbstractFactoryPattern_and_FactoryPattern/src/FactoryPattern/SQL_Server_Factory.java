package FactoryPattern;

public class SQL_Server_Factory implements AccessFactory {

	@Override
	public Database create() {
		return new SQL_Server();
	}

}
