package AbstractFactoryPattern;

public interface IProduct {
	
	public void InsertProduct(Product product);
	public void GetProduct();
}
