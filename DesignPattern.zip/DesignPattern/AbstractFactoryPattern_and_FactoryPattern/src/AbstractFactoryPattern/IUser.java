package AbstractFactoryPattern;

public interface IUser {
	
	public void InsertUser(User user);
	public void GetUser();
}
