package AbstractFactoryPattern;

public class User {
	private String UserID;
	private String UserName;
	private int Userlevel;	
	
	public User() {
		super();
	}

	public User(String userID, String userName, int userlevel) {
		super();
		UserID = userID;
		UserName = userName;
		Userlevel = userlevel;
	}

	public String getUserID() {
		return UserID;
	}

	public void setUserID(String userID) {
		UserID = userID;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public int getUserlevel() {
		return Userlevel;
	}

	public void setUserlevel(int userlevel) {
		Userlevel = userlevel;
	}
	
	public void printf() {
		System.out.println("���Ϊ"+this.UserID+"���û�"+this.UserName+"�ĵȼ���"+this.Userlevel);
	}
	
	
}
