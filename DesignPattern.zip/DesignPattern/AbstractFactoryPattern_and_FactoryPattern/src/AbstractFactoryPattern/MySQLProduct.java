package AbstractFactoryPattern;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class MySQLProduct implements IProduct {

	public DbUtil dbutil = new DbUtil();
	
	@Override
	public void InsertProduct(Product product) {
		String sql = "insert into productinfo (product_id,product_nm,product_price,made_place,product_type)"
					//+" values (?,?,?,?,?)";
					+ "values('"+product.getProduct_id()+"','"+product.getProduct_nm()+"','"
					+product.getProduct_price()+"','"+product.getmade_palce()+"','"+product.getProduct_type()+"')";
		
	try {
		Statement pstr = dbutil.getCon().createStatement();
//		pstr.setString(1, product.getProduct_id());
//		pstr.setString(2, product.getProduct_nm());
//		pstr.setDouble(3, product.getProduct_price());
//		pstr.setString(4, product.getmade_palce());
//		pstr.setString(5, product.getProduct_type());	
		int flag = pstr.executeUpdate(sql);
		if(flag == 1) {
			System.out.println("Insert Product Successfully!");
		}else {
			System.out.println("Insert Product Faild!");
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
		
	}

	@Override
	public void GetProduct() {
		Product product;
		String sql = "select * from productinfo limit 10";
		try {
			Statement pstr = dbutil.getCon().createStatement();
			ResultSet rs = pstr.executeQuery(sql);
			while(rs.next()) {
				product = new Product(rs.getString("product_id"), rs.getString("product_nm"), rs.getDouble("product_price"),
						rs.getString("made_place"),rs.getString("product_type"));
				product.printf();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public static void main(String[] args) {
		MySQLProduct test = new MySQLProduct();
		test.InsertProduct(new Product("G512", "����", 390.5, "�й�", "����"));
		test.GetProduct();
	}
}
