package AbstractFactoryPattern;

import java.sql.ResultSet;
import java.sql.Statement;

public class MySQLUser implements IUser {

	public DbUtil dbutil = new DbUtil();
	
	@Override
	public void InsertUser(User user) {
		String sql = "Insert into userinfo (UserID,UserName,Userlevel)"
					+" values('"+user.getUserID()+"','"+user.getUserName()+"','"
					+user.getUserlevel()+"')";
		try {
			Statement pstr = dbutil.getCon().createStatement();
			int flag = pstr.executeUpdate(sql);
			if(flag == 1) {
				System.out.println("Insert User Successfully!");
			}else {
				System.out.println("Insert User Faild!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void GetUser() {
		User user;
		String sql = "select * from userinfo limit 3";
		try {
			Statement pstr = dbutil.getCon().createStatement();
			ResultSet rs = pstr.executeQuery(sql);
			while(rs.next()) {
				user = new User(rs.getString("UserID"), rs.getString("UserName"), rs.getInt("Userlevel"));
				user.printf();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		MySQLUser test = new MySQLUser();
		test.InsertUser(new User("B003", "summer", 12));
		test.GetUser();
	}
	
}
