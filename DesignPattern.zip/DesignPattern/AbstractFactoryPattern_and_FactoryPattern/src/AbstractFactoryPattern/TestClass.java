package AbstractFactoryPattern;

public class TestClass {
	public static void main(String[] args) {
		DbFactory F = new MySQLFactory();//operate MySQL
//		DbFactory F = new AccessFactory();//operate Access
		
		//������Բ���Userinfo
		IUser User = F.OperateUserInfo();
		User.InsertUser(new User("brooke", "���л�", 100));
		User.GetUser();
		
		//������Բ���Productinfo
		IProduct product = F.OperateProductInfo();
		product.InsertProduct(new Product("A007", "summer", 1040.5, "����", "humen"));
		product.GetProduct();
	}
}
