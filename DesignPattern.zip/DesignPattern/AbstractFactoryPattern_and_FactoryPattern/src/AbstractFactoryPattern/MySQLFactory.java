package AbstractFactoryPattern;

public class MySQLFactory implements DbFactory {

	@Override
	public IProduct OperateProductInfo() {
		return new MySQLProduct();
	}

	@Override
	public IUser OperateUserInfo() {
		return new MySQLUser();
	}

}
