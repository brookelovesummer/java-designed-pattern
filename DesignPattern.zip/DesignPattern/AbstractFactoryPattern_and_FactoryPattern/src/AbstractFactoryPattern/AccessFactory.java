package AbstractFactoryPattern;

public class AccessFactory implements DbFactory{

	@Override
	public IProduct OperateProductInfo() {
		return new AccessProduct();
	}

	@Override
	public IUser OperateUserInfo() {
		return new AccessUser();
	}

}
