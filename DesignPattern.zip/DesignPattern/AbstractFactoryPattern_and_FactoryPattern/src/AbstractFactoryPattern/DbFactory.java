package AbstractFactoryPattern;

public interface DbFactory {
	public IProduct OperateProductInfo();
	public IUser OperateUserInfo();
}
