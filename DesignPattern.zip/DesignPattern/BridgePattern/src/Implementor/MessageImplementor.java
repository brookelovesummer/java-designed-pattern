package Implementor;

public interface MessageImplementor {

	public void send(String message,String toUser);
}
