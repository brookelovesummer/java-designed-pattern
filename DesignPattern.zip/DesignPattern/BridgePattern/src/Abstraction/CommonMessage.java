package Abstraction;

import Implementor.MessageImplementor;

public class CommonMessage extends AbstractMessage{

	public CommonMessage(MessageImplementor mImpl) {
		super(mImpl);
	}

	@Override
	public void SendMessage(String message, String toUser) {
		super.SendMessage(message, toUser);
	}
	
}
