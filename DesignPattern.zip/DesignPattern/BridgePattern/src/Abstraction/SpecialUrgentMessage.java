package Abstraction;

import Implementor.MessageImplementor;

public class SpecialUrgentMessage extends AbstractMessage{

	public SpecialUrgentMessage(MessageImplementor mImpl) {
		super(mImpl);
	}

	@Override
	public void SendMessage(String message, String toUser) {
		message += "�ؼ�";
		super.SendMessage(message, toUser);
	}

	
	
}
