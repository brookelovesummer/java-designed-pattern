package Abstraction;

import Implementor.MessageImplementor;

public abstract class AbstractMessage {

	private MessageImplementor MImpl;

	public AbstractMessage(MessageImplementor mImpl) {
		super();
		MImpl = mImpl;
	}
	public void SendMessage(String message,String  toUser) {
		this.MImpl.send(message, toUser);
	}
}
