package Abstraction;

import Implementor.MessageImplementor;

public class UrgentMessage extends AbstractMessage {

	public UrgentMessage(MessageImplementor mImpl) {
		super(mImpl);
	}

	@Override
	public void SendMessage(String message, String toUser) {
		super.SendMessage(message, toUser);
	}

	
}
