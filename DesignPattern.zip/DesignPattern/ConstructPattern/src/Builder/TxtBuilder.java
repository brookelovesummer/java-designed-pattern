package Builder;

import java.io.File;
import java.io.FileWriter;
import java.util.Collection;
import java.util.Map;

import Model.BodyModel;
import Model.FooterModel;
import Model.HeaderModel;

public class TxtBuilder implements Builder{
	
	public StringBuffer buffer = new StringBuffer();

	@Override
	public void buildheader(HeaderModel head) {
		buffer.append(head.getVersionid()+","+head.getExportDate()+"\n");
		
	}

	@Override
	public void buildbody(Map<String, Collection<BodyModel>> body) {
		for(String tbName : body.keySet()) {
			buffer.append(tbName+"\n");
			for(BodyModel bod : body.get(tbName)) {
				buffer.append(bod.getProductnm()+","+bod.getProductCatgory()+","
							+bod.getProvince()+","+bod.getCity()+","+bod.getPrice()+"\n"
				
						);
			}
		}
		
	}

	@Override
	public void buildfooter(FooterModel foot) {
		buffer.append(foot.getExportUser());
		
	}

	public StringBuffer getResult() throws Exception{
		String path = "D:\\eclipse work space\\Java_DesignePatterns\\ConstructPattern\\src\\Test.txt";
		File file=new File(path);
		boolean b=file.createNewFile();
		if(b) {
			FileWriter out1 = new FileWriter(file);// �����ļ������
			out1.write(buffer.toString() + "\n");
			out1.close();
		}
		
		return buffer;
	}


}
