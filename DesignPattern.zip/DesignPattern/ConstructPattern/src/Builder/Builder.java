package Builder;

import java.util.Collection;
import java.util.Map;

import Model.BodyModel;
import Model.FooterModel;
import Model.HeaderModel;

public interface Builder {
	public void buildheader(HeaderModel head);
	public void buildbody(Map<String,Collection<BodyModel>> body);
	public void buildfooter(FooterModel foot);
}
