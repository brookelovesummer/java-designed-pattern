package Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import Builder.TxtBuilder;
import Director.Director;
import Model.BodyModel;
import Model.FooterModel;
import Model.HeaderModel;

public class BuilderPatternEC {
	
	public static void main(String[] args) throws Exception{
		HeaderModel head = new HeaderModel();
		head.setVersionid("version: 1.0");
		head.setExportDate(new Date().toString());
		
		Map<String,Collection<BodyModel>> mapdata = new HashMap<String,Collection<BodyModel>>();
		Collection<BodyModel> col = new ArrayList<BodyModel>();
		BodyModel body1 = new BodyModel();
		body1.setProductnm("����5ϵ");
		body1.setProductCatgory("Car");
		body1.setProvince("����");
		body1.setCity("������");
		body1.setPrice(1000000);
		
		BodyModel body2 = new BodyModel();
		body2.setProductnm("һ������");
		body2.setProductCatgory("Car");
		body2.setProvince("�Ϻ�");
		body2.setCity("�Ϻ���");
		body2.setPrice(200000);
		
		col.add(body1);
		col.add(body2);
		mapdata.put("�������ƣ��������ʡ���У������۸�", col);
		
		FooterModel foot = new FooterModel();
		foot.setExportUser("brooke");
		
		TxtBuilder txtbuilder = new TxtBuilder();
		Director director = new Director(txtbuilder);
		director.Construct(head, mapdata, foot);
		System.out.println(txtbuilder.getResult());
	
	}
}
