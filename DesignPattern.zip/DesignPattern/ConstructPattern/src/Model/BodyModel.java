package Model;

import java.util.Date;

public class BodyModel {
	private String productnm;
	private String productCatgory;
	private String province;
	private String city;
	private double price;
	public String getProductnm() {
		return productnm;
	}
	public void setProductnm(String productnm) {
		this.productnm = productnm;
	}
	public String getProductCatgory() {
		return productCatgory;
	}
	public void setProductCatgory(String productCatgory) {
		this.productCatgory = productCatgory;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	public static void main(String[] args) {
		System.out.println(new Date().toString());
	}
}
