package Director;

import java.util.Collection;
import java.util.Map;

import Builder.Builder;
import Model.BodyModel;
import Model.FooterModel;
import Model.HeaderModel;

public class Director {
	private Builder builder;

	public Director(Builder builder) {
		super();
		this.builder = builder;
	}
	
	public void Construct(HeaderModel head,Map<String,Collection<BodyModel>> body,
			FooterModel foot) {
		builder.buildheader(head);
		builder.buildbody(body);
		builder.buildfooter(foot);
		
	}
}
