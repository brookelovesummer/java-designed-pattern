package web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Command.Command;
import Model.TUser;
import TDao.TUserDao;

/**
 * Servlet implementation class MyServlet
 */
@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=UTF-8");
		String commandtype = request.getParameter("type");
//		System.out.println(commandtype);
		String username = request.getParameter("UserName");
		String userid = request.getParameter("UserID");
		String level = request.getParameter("UserLevel");
		int userlevel = 0;
		TUser user = new TUser();
		user.setUserID(userid);
		user.setUserName(username);
		if(level != null && level != ""){
			userlevel = Integer.parseInt(level);
			user.setUserLevel(userlevel);
		}
  		TUserDao userdao = new TUserDao();
		try {
			Command command =(Command)(Class.forName("Command."+commandtype).newInstance());
			command.setReciver(userdao);
			command.setUser(user);
//			System.out.println(user.getUserID()+user.getUserName()+user.getUserLevel());
			command.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.getRequestDispatcher("index.jsp").forward(request, response);
	}

}
