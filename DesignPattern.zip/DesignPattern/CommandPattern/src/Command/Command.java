package Command;

import Model.TUser;
import TDao.TUserDao;

public interface Command {

	public void execute();
	public void setReciver(TUserDao userdao);
	public void setUser(TUser user);
}
