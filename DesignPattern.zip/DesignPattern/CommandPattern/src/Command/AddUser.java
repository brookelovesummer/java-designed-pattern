package Command;

import Model.TUser;
import TDao.TUserDao;

public class AddUser implements Command {

	TUserDao userdao;
	TUser user;
	@Override
	public void execute() {
		userdao.adduser(user);		
	}

	@Override
	public void setReciver(TUserDao userdao) {
		this.userdao = userdao;	
	}

	@Override
	public void setUser(TUser user) {
		this.user = user;	
	}

}
