package TDao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import Model.TUser;
import Util.DbUtil;

public class TUserDao {

	private DbUtil dbutil = new DbUtil();
	private Connection con ;
	
	public void updatelevel(TUser user){
		//ע�������User����ID���û�������Level���µĵȼ���
		try {
			con = dbutil.getCon();
			String sql = "update userinfo set UserLevel=? where UserID = ?";
			PreparedStatement psmt = con.prepareStatement(sql);
			psmt.setInt(1, user.getUserLevel());
			psmt.setString(2, user.getUserID());
			psmt.execute();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void adduser(TUser user){
		try {
			con = dbutil.getCon();
			String sql = "insert into userinfo values(?,?,?)";
			PreparedStatement psmt = con.prepareStatement(sql);
			psmt.setString(1, user.getUserID());
			psmt.setString(2, user.getUserName());
			psmt.setInt(3, user.getUserLevel());
			psmt.execute();
			con.close();
//			System.out.println("ִ�е�������");		
		} catch (Exception e) {
			System.out.println(e);
		}
		
	}
	
	
	public void deleteuser(TUser user){
		try {
			con = dbutil.getCon();
			String sql = "delete from userinfo where UserID=?";
			PreparedStatement psmt = con.prepareStatement(sql);
			psmt.setString(1, user.getUserID());
			psmt.execute();
			con.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public static void main(String[] args) {
		TUserDao test = new TUserDao();
		TUser user = new TUser();
		user.setUserID("1");
		user.setUserName("brooke");
		user.setUserLevel(1);
		test.adduser(user);
	}
}
