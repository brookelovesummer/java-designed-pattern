package Composite;

import java.util.ArrayList;
import java.util.List;

import Component.Component;

public class Composite extends Component {
	
	private List<Component> childcomponents;
	private String name = "";

	public Composite(String name) {
		super();
		this.name = name;
	}

	@Override
	public void printStruct(String preStr) {
		System.out.println(preStr + "+" + name);
		if(childcomponents != null) {
			preStr += " ";
			for(Component c : childcomponents) {
				c.printStruct(preStr);
			}
		}
		
	}

	@Override
	public void addChild(Component child) {
		// TODO Auto-generated method stub
		if(childcomponents == null) {
			childcomponents = new ArrayList<Component>();
		}
		childcomponents.add(child);
	}

	@Override
	public void removeChild(Component child) {
		if(childcomponents == null) {
			System.out.println("��ǰ������û�ж��󣬲��ɽ����Ƴ�������");
		}
		childcomponents.remove(child);
		
	}

	@Override
	public Component getChildren(int index) {
		return childcomponents.get(index);
	}

}
