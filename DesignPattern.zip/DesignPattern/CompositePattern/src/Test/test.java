package Test;

import Component.Component;
import Composite.Composite;
import Leaf.Leaf;

public class test {

	public static void main(String[] args) {
		Component root = new Composite("��װ");
		Component c1 = new Composite("Ůװ");
		Component c2 = new Composite("��װ");
		Component c3 = new Composite("��װ���");
		
		Component l1 = new Leaf("����");
		Component l2 = new Leaf("���޷�");
		Component l3 = new Leaf("����");
		Component l4 = new Leaf("Χ��");
		Component l5 = new Leaf("ñ��");
		
		root.addChild(c1);
		root.addChild(c2);
		root.addChild(c3);
		c1.addChild(l1);
		c1.addChild(l2);
		c1.addChild(l3);
		c2.addChild(l1);
		c2.addChild(l2);
		c2.addChild(l3);
		c3.addChild(l4);
		c3.addChild(l5);
		
		root.printStruct("");
	}
}
