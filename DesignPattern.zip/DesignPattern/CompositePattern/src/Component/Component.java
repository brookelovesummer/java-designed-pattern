package Component;

public abstract class Component {

	public abstract void printStruct(String preStr);
	public abstract void addChild(Component child);
	public abstract void removeChild(Component child);
	public abstract Component getChildren(int index);
}
