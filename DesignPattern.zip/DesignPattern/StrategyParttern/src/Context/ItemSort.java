package Context;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import Bean.ItemBean;

public class ItemSort {
	public static List<ItemBean> sortlist(List<ItemBean> items,Comparator<ItemBean> c)throws Exception{
		Collections.sort(items,c);
		return items;
	}

}
