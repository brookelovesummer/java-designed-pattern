package Strategy;

import java.util.Comparator;

import Bean.ItemBean;

public class PopularComparetor implements Comparator<ItemBean> {

	@Override
	public int compare(ItemBean o1, ItemBean o2) {
		return o2.getPopular()-o1.getPopular();
	}

}
