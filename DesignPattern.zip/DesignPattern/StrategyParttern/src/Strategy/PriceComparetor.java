package Strategy;

import java.util.Comparator;

import Bean.ItemBean;

public class PriceComparetor implements Comparator<ItemBean> {

	@Override
	public int compare(ItemBean o1, ItemBean o2) {
		return (int)(o2.getPrice()-o1.getPrice());
	}

}
