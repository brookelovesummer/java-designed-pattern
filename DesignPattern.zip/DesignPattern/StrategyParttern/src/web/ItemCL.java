package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Bean.ItemBean;
import Context.ItemSort;

/**
 * Servlet implementation class ItemCL
 */
@WebServlet("/ItemCL")
public class ItemCL extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ItemCL() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		//init
		String type = request.getParameter("type");

		
		List<ItemBean> itemlist = new ArrayList<ItemBean>();
		ItemBean a1 = new ItemBean();
		a1.setCredit(90);
		a1.setPopular(300);
		a1.setPrice(814.0);
		a1.setSale(3626);
		a1.setPicpath("images/1.jpg");
		itemlist.add(a1);
		ItemBean a2 = new ItemBean();
		a2.setCredit(70);
		a2.setPopular(400);
		a2.setPrice(98.0);
		a2.setSale(1119);
		a2.setPicpath("images/2.jpg");
		itemlist.add(a2);
		ItemBean a3 = new ItemBean();
		a3.setCredit(40);
		a3.setPopular(80);
		a3.setPrice(138.0);
		a3.setSale(638);
		a3.setPicpath("images/3.jpg");
		itemlist.add(a3);
		ItemBean a4 = new ItemBean();
		a4.setCredit(170);
		a4.setPopular(400);
		a4.setPrice(50.0);
		a4.setSale(559);
		a4.setPicpath("images/4.jpg");
		itemlist.add(a4);
		
		try {
			Object c = Class.forName("Strategy."+type).newInstance();
			ItemSort.sortlist(itemlist, (Comparator) c);
			request.setAttribute("result", itemlist);
			request.getRequestDispatcher("index.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			out.close();
		}
		
		
		
	}

}
