package Util;

import java.util.ArrayList;
import java.util.List;

import Bean.ItemBean;

public class Itemlist {
	static List<ItemBean> items = new ArrayList<ItemBean>();

	public static List<ItemBean> getItems() {
		return items;
	}

	public static void setItems(List<ItemBean> items) {
		Itemlist.items = items;
	}
	
	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
		list.add("1");
		list.add("22");
		list.add("333");
		String str = list.get(0);
		System.out.println(str);
		
	}

}
