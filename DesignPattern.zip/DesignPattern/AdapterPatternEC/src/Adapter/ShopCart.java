package Adapter;

import java.util.ArrayList;

import model.Product;

public class ShopCart {
	private ArrayList<Product> myitems = new ArrayList<Product>();

	public void setMyitems(ArrayList<Product> myitems) {
		this.myitems = myitems;
	}
	
	public void placeorder(Product x){
		if(x != null){
			if(myitems.size() == 0){
				Product temp = new Product();
				temp.setPname(x.getPname());
				temp.setPicpath(x.getPicpath());
				temp.setPprice(x.getPprice());
				temp.setAmount(x.getAmount());
				myitems.add(temp);
			}else{
				boolean flag = false;
				for(Product temp : myitems){
					if(temp.getPname().equals(x.getPname())){
						temp.setAmount(temp.getAmount()+1);
						flag = true;
						break;
					}
				}
				if(flag){
					Product temp = new Product();
					temp.setPname(x.getPname());
					temp.setPicpath(x.getPicpath());
					temp.setPprice(x.getPprice());
					temp.setAmount(x.getAmount());
					myitems.add(temp);
				}
			}
		}
	}
}
