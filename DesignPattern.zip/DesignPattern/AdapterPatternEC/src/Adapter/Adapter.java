package Adapter;

import java.util.ArrayList;

import model.Product;

public class Adapter implements Target{
	
	ShopCart mycart;
	ArrayList<Product> linkitems = new ArrayList<Product>();

	public Adapter(ShopCart mycart) {
		super();
		this.mycart = mycart;
	}

	@Override
	public void placeorder(Product x) {
		mycart.placeorder(x);
		
	}

	@Override
	public ArrayList<Product> add_linkgoods() {
		Product l1 = new Product();
		l1.setPicpath("Images/1.jpg");
		linkitems.add(l1);
		Product l2 = new Product();
		l2.setPicpath("Images/2.jpg");
		linkitems.add(l2);
		Product l3 = new Product();
		l3.setPicpath("Images/3.jpg");
		linkitems.add(l3);
		Product l4 = new Product();
		l4.setPicpath("Images/4.jpg");
		linkitems.add(l4);
		return linkitems;
	}

}
