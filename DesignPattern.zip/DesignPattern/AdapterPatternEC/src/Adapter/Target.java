package Adapter;

import java.util.ArrayList;

import model.Product;

public interface Target {
	public void placeorder(Product x);
	public ArrayList<Product> add_linkgoods();
}
