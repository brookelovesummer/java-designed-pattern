package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Product;
import Adapter.Adapter;
import Adapter.ShopCart;
import Adapter.Target;

/**
 * Servlet implementation class purchase
 */
@WebServlet("/purchase")
public class purchase extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public purchase() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		try{
			String pamount = request.getParameter("pamount");
			Product myproduct = new Product();
			myproduct.setPname("������ʱ������ʷ��������������ҵ��������ݿ�ѧ");
			myproduct.setPicpath("Images/data.jpg");
			myproduct.setPprice(58.0);
			myproduct.setAmount(Integer.parseInt(pamount));
			
			ArrayList<Product> mybuylist = new ArrayList<Product>();
			ShopCart mycart = new ShopCart();
			mycart.setMyitems(mybuylist);
			Target xxx = new Adapter(mycart);
			xxx.placeorder(myproduct);
			
			ArrayList<Product> linklist = xxx.add_linkgoods();
			HttpSession mysession = request.getSession();
			mysession.setAttribute("mygoods", mybuylist);
			mysession.setAttribute("linkgoods", linklist);
//			request.getRequestDispatcher("showproduct.jsp").forward(request, response);
			response.sendRedirect("showproduct.jsp");
		}finally{
			out.close();
		}
	}

}
