package model;

public class Order {

	private String personInfomation;
	private String address;
	private String productList;
	
	
	public String getPersonInfomation() {
		return personInfomation;
	}
	public void setPersonInfomation(String personInfomation) {
		this.personInfomation = personInfomation;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getProductList() {
		return productList;
	}
	public void setProductList(String productList) {
		this.productList = productList;
	}
	
	
}
