package Colleague;

import model.Order;

public class DeliveryMan extends Notice{

	private String deliverymanName = "����";

	public String getDeliverymanName() {
		return deliverymanName;
	}

	public void setDeliverymanName(String deliverymanName) {
		this.deliverymanName = deliverymanName;
	}
	
	public void FindCustomerAndSendProducts(Order order) {
		System.out.println("�����ͻ�Ա"+deliverymanName+"�������ѵ���"+order.getAddress());
		noticeDangdang(this);
	}
}
