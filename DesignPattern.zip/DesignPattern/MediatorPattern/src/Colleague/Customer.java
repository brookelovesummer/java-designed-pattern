package Colleague;

import model.Order;

public class Customer extends Notice{

	private Order order;
	
	public Order getOrder() {
		return order;
	}
	
	public void sendOrder(Order order) {
		this.order = order;
		noticeDangdang(this);
	}
}
