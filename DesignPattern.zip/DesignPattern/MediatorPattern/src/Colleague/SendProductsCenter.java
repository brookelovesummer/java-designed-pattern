package Colleague;

import java.util.LinkedList;

import model.Order;

public class SendProductsCenter extends Notice {
	private static SendProductsCenter center = new SendProductsCenter();

	public static SendProductsCenter getCenter() {
		return center;
	}
	public LinkedList<DeliveryMan> deliverymanlist = new LinkedList<DeliveryMan>();
	public void addDeliveryMan(DeliveryMan deliveryman) {
		deliverymanlist.push(deliveryman);
	}
	public DeliveryMan getDeliveryman() {
		return deliverymanlist.poll();
	}
	
	public void SendProducts(Order order) {
		DeliveryMan man = new DeliveryMan();
		addDeliveryMan(man);
		DeliveryMan deliveryman = new DeliveryMan();
		noticeDangdang(this);
		deliveryman.FindCustomerAndSendProducts(order);
	}
}
