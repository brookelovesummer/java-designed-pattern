package Colleague;

import Mediator.Dangdang;

public abstract class Notice {

	public void noticeDangdang(Notice notice) {
		Dangdang.getInstance().executeNotice(notice);
	}
}
