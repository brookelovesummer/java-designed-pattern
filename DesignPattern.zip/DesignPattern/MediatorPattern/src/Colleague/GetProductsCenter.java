package Colleague;

import model.Order;

public class GetProductsCenter extends Notice {

	private static GetProductsCenter center = new GetProductsCenter();
	
	public static GetProductsCenter getInstance() {
		return center;
	}
	
	public void getProduct(Order order) {
		System.out.println("�Ӳֿ�ȡ��"+order.getProductList());
		noticeDangdang(this);
	}
}
