package Flyweight;

import java.util.HashMap;
import java.util.Map;

public class ChessFactory {

	private Map<String,AChess> mychesses = new HashMap<String,AChess>();
	
	public AChess getAChess(String color) {
		AChess mychess = mychesses.get(color);
		if(mychess != null) {
			return mychess;
		}else {
			mychess = new ConcreteChess(color);
			mychesses.put(color, mychess);
			return mychess;
		}
	}
	
	public int getmychessesNum() {
		return mychesses.size();
	}
}
