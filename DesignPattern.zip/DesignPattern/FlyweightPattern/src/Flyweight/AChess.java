package Flyweight;

import model.Location;

public abstract class AChess {
	public abstract void locate(Location location);
}
