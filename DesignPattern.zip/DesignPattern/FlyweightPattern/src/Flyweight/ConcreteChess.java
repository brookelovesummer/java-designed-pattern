package Flyweight;

import model.Location;

public class ConcreteChess extends AChess {

	private String color;
	
	public ConcreteChess(String color) {
		super();
		this.color = color;
	}

	@Override
	public void locate(Location location) {
		System.out.println(this.color+"���ӵ�����Ϊ��"+location.getX()+"��"+location.getY()+"��");
		
	}
	
	public static void main(String[] args) {
		ConcreteChess test = new ConcreteChess("��ɫ");
		test.locate(new Location(1, 2));
	}

}
