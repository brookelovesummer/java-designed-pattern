package Test;

import Flyweight.AChess;
import Flyweight.ChessFactory;
import model.Location;

public class test {
	public static void main(String[] args) {
		ChessFactory CF = new ChessFactory();
		AChess AC1 = CF.getAChess("��ɫ");
		AC1.locate(new Location(1, 2));
		AChess AC2 = CF.getAChess("��ɫ");
		AC2.locate(new Location(3, 4));
		AChess AC3 = CF.getAChess("��ɫ");
		AC3.locate(new Location(2, 6));
		AChess AC4 = CF.getAChess("��ɫ");
		AC4.locate(new Location(10, 2));
		System.out.println("��������"+CF.getmychessesNum()+"������");
	}
	
}
