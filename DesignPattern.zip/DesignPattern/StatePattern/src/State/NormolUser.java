package State;

import Context.User;

public class NormolUser extends UserLevel {

	public NormolUser(User user) {
		super(user);
	}

	@Override
	public void StateCheck() {
		if(user.getPaidmoney() > 1000) {
			user.setUserlevel(user.Silveruser);
		}
		
	}

	@Override
	public double CalcRealpaids(double paids) {
		return paids * 0.95;
	}

}
