package State;

import Context.User;

public class GoldUser extends UserLevel {

	public GoldUser(User user) {
		super(user);
	}

	@Override
	public void StateCheck() {
		if(user.getPaidmoney() > 5000) {
			user.setUserlevel(user.Diamonduser);
		}
		
	}

	@Override
	public double CalcRealpaids(double paids) {
		return paids * 0.8;
	}

}
