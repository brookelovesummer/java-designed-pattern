package State;

import Context.User;

public class DiamondUser extends UserLevel {

	public DiamondUser(User user) {
		super(user);
	}

	@Override
	public void StateCheck() {
		System.out.println("DiamondUser is the highest level!");
	}

	@Override
	public double CalcRealpaids(double paids) {
		return paids * 0.7;
	}

}
