package State;

import Context.User;

public abstract class UserLevel {

	protected User user;

	public UserLevel(User user) {
		super();
		this.user = user;
	}
	public abstract void StateCheck();
	public abstract double CalcRealpaids(double paids);
}
