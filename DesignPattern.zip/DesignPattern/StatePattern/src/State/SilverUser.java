package State;

import Context.User;

public class SilverUser extends UserLevel {

	public SilverUser(User user) {
		super(user);
	}

	@Override
	public void StateCheck() {
		if(user.getPaidmoney() > 2000) {
			user.setUserlevel(user.Golduser);
		}
		
	}

	@Override
	public double CalcRealpaids(double paids) {
		return paids * 0.9;
	}

}
