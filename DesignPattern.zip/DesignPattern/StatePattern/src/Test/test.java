package Test;

import Context.User;

public class test {

	public static void main(String[] args) {
		User user = new User("brooke");
		user.BuyBooks(2000);
		user.BuyBooks(2000);
		user.BuyBooks(2000);
		user.BuyBooks(2000);
	}
}
