package Context;

import State.DiamondUser;
import State.GoldUser;
import State.NormolUser;
import State.SilverUser;
import State.UserLevel;

public class User {

	private String username;
	private UserLevel userlevel;
	private double paidmoney;
	
	public final UserLevel Normoluser = new NormolUser(this);
	public final UserLevel Silveruser = new SilverUser(this);
	public final UserLevel Golduser = new GoldUser(this);
	public final UserLevel Diamonduser = new DiamondUser(this);	
	
	public User(String username) {
		super();
		this.username = username;
		this.paidmoney = 0;
		this.userlevel = this.Normoluser;
	}
	public String getName() {
		return username;
	}
	public void setName(String name) {
		this.username = name;
	}
	public UserLevel getUserlevel() {
		return userlevel;
	}
	public void setUserlevel(UserLevel userlevel) {
		this.userlevel = userlevel;
	}
	public double getPaidmoney() {
		return paidmoney;
	}
	public void setPaidmoney(double paidmoney) {
		this.paidmoney = paidmoney;
	}
	
	public void BuyBooks(double paids) {
		System.out.println("Hello!"+username+",You have paid:"+paidmoney+",Your level is:"
				+userlevel.getClass().getSimpleName());
		double realpaids = userlevel.CalcRealpaids(paids);
		System.out.println("You only need to paid $"+realpaids+" for these books.");
		paidmoney += realpaids;
		userlevel.StateCheck();
	}
}
