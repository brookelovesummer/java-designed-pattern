package model;

public class Product {
	
	private String product_id;
	private String product_nm;
	private double product_price;
	private String made_palce;
	private String product_type;
	
	public String getProduct_id() {
		return product_id;
	}
	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}
	public String getProduct_nm() {
		return product_nm;
	}
	public void setProduct_nm(String product_nm) {
		this.product_nm = product_nm;
	}
	public double getProduct_price() {
		return product_price;
	}
	public void setProduct_price(double product_price) {
		this.product_price = product_price;
	}
	public String getmade_palce() {
		return made_palce;
	}
	public void setmade_palce(String product_madepalce) {
		this.made_palce = product_madepalce;
	}
	public String getProduct_type() {
		return product_type;
	}
	public void setProduct_type(String product_type) {
		this.product_type = product_type;
	}
	
	public void printf() {
		System.out.println("���Ϊ"+this.product_id+"�Ĳ�Ʒ"+this.product_nm+"�ļ۸���"+this.product_price+"�����ǣ�"+this.made_palce+"�����ǣ�"+this.product_type);
	}
}
