package ConcreteHandler;

import Handler.Filter;
import Util.FilterChain;
import Util.InputMsg;

public class SensitiveFilter implements Filter{

	@Override
	public void doFilter(InputMsg msg, FilterChain F) {
		msg.setRequest(msg.getRequest().replace("ɽկ", "XXX"));
		msg.setRequest(msg.getRequest().replace("ˮ��", "XXX"));
		F.doFilter(msg, F);
	}

}
