package ConcreteHandler;

import Handler.Filter;
import Util.FilterChain;
import Util.InputMsg;

public class HTMLFilter implements Filter {

	@Override
	public void doFilter(InputMsg msg, FilterChain F) {
		msg.setRequest(msg.getRequest().replace("<html>", "[html]"));
		F.doFilter(msg, F);
	}

}
