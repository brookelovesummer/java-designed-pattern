package Handler;

import Util.FilterChain;
import Util.InputMsg;

public interface Filter {

	public void doFilter(InputMsg msg,FilterChain F);
}
