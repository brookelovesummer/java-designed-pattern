package Util;

import java.util.ArrayList;
import java.util.List;

import Handler.Filter;

public class FilterChain implements Filter {
	
	private List<Filter> list = new ArrayList<Filter>();
	private int index = 0;
	@Override
	public void doFilter(InputMsg msg, FilterChain F) {
		if(index == list.size()){
			return;//��˵���������Ѿ��������
		}
		Filter f = list.get(index);
		index++;
		f.doFilter(msg, F);
	}
	public FilterChain addFilter(Filter F){
		list.add(F);
		return this;
	}


}
