package Util;

public class InputMsg {

	private String request="";

	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}
	
	
}
